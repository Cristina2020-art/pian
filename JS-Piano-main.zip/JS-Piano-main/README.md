# JS-Piano
Interactive piano in html css and javascript
